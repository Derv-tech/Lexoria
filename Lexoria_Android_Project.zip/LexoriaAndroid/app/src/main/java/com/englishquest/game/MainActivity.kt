package com.englishquest.game

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.content.Context
import android.content.SharedPreferences
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContentView(QuestView(this))
    }
}

data class Question(val region:String,val level:Int,val prompt:String,val options:List<String>,val answer:Int,val explain:String)
class QuestView(ctx:Context):View(ctx) {
    private val prefs:SharedPreferences=ctx.getSharedPreferences("quest_save",Context.MODE_PRIVATE)
    private val paint=Paint().apply{isAntiAlias=false;typeface=Typeface.create("monospace",Typeface.BOLD)}
    private val rng=java.util.Random(17)
    private var scene="world"; private var region="Grammar Castle"; private var dialog="Welcome, wordkeeper! The Wordstone is broken. Help us restore language to Lexicon."
    private var playerX=0f; private var playerY=0f; private var moveX=0f; private var moveY=0f
    private var xp=prefs.getInt("xp",0); private var gold=prefs.getInt("gold",0); private var gems=prefs.getInt("gems",0)
    private var lessons=prefs.getInt("lessons",0); private var correct=prefs.getInt("correct",0); private var shards=prefs.getInt("shards",0)
    private var hearts=3; private var qIndex=0; private var answered=false; private var chosen=-1; private var feedback=""
    private var lastTime=System.currentTimeMillis(); private var unlocked=prefs.getInt("unlocked",0)
    private var name=prefs.getString("hero","Wordkeeper") ?: "Wordkeeper"
    private var storyChapter=prefs.getInt("storyChapter",0)
    private val storyChapters=listOf(
        Pair("PROLOGUE: THE LAST WORD", "The Wordstone shattered. Words faded from signs, books, and memories. You discover a glowing shard and hear a voice: “Find the others.”"),
        Pair("CHAPTER 1: A VILLAGE WITHOUT NAMES", "In Bramblewick, shop signs are blank and neighbors struggle to understand one another. Help Mira the librarian restore everyday words and earn the villagers’ trust."),
        Pair("CHAPTER 2: THE GRAMMAR GATE", "A stone gate asks riddles about sentences and verbs. The gatekeeper, Orin, explains that language is a bridge: each correct answer repairs one of its cracked runes."),
        Pair("CHAPTER 3: THE FOREST THAT LISTENS", "In the Listening Forest, echoes repeat half-truths. Follow clues, distinguish what you hear from what you infer, and help Pip the fox find the path home."),
        Pair("CHAPTER 4: THE INKBOUND MOUNTAINS", "The mountain archives have been scrambled. Rebuild paragraphs, revise letters, and discover the journal of a scholar who once studied the Silence King."),
        Pair("CHAPTER 5: THE CITY OF MANY VOICES", "Merchants, travelers, and inventors use different registers and expressions. Learn to adjust your words for friendly conversation, school, and work."),
        Pair("CHAPTER 6: THE SHATTERED LIBRARY", "A library maze tests reading comprehension, context clues, and the difference between a narrator’s claim and the evidence on the page."),
        Pair("CHAPTER 7: THE SILENCE KING", "At the ruined citadel, the Silence King reveals that he once feared being misunderstood. Restore the final shard by using precise, thoughtful language—not force alone."),
        Pair("EPILOGUE: A LIVING LANGUAGE", "Lexicon begins to heal. The Wordstone is restored, but new paths appear beyond the map. Mastery is not an ending: every conversation opens another door.")
    )
    private val questions=listOf(
        Question("Grammar Castle",0,"Choose the correct sentence.",listOf("She are happy.","She is happy.","She am happy."),1,"Use “is” with she: She is happy."),
        Question("Grammar Castle",0,"Complete: I ___ ready.",listOf("am","is","are"),0,"Use “am” with I."),
        Question("Vocabulary Village",0,"What does “enormous” mean?",listOf("Very small","Very large","Very quiet"),1,"Enormous means extremely large."),
        Question("Reading Realm",0,"Mia has a red bag. What color is her bag?",listOf("Blue","Red","Green"),1,"The text says the bag is red."),
        Question("Writing Mountains",0,"Which sentence is capitalized correctly?",listOf("my name is Lee.","My name is Lee.","My Name is lee."),1,"Capitalize the first word and a person's name."),
        Question("Speaking Port",0,"Ask someone to repeat politely.",listOf("Say again now.","Could you say that again, please?","You talk bad."),1,"This is a polite, natural request."),
        Question("Listening Forest",1,"“Wanna grab a bite?” usually means…",listOf("Want to eat something?","Want to fight?","Want to read?"),0,"“Grab a bite” means get something to eat."),
        Question("Real World City",1,"At a shop, a receipt is…",listOf("Proof of purchase","A discount","A shopping bag"),0,"A receipt records a purchase."),
        Question("Challenge Arena",2,"Choose the correct sentence.",listOf("Neither answer is correct.","Neither answers are correct.","Neither answer be correct."),0,"“Neither” is commonly singular in standard formal English."),
        Question("Advanced Academy",3,"“Cogent” most nearly means…",listOf("Persuasive and logical","Loud and unrelated","Vague"),0,"Cogent means clear, logical, and convincing."),
        Question("Advanced Academy",3,"Which is a cautious academic claim?",listOf("This proves everything forever.","The findings may suggest a relationship.","Nobody can disagree."),1,"Academic writing often qualifies claims carefully.")
    )
    private val regions=listOf(
        Triple("Grammar Castle","🏰","Tenses, sentences, punctuation"),
        Triple("Vocabulary Village","🏘","Words, meanings, idioms"),
        Triple("Reading Realm","📚","Stories and comprehension"),
        Triple("Writing Mountains","✍","Paragraphs, essays, style"),
        Triple("Speaking Port","🗣","Conversation and fluency"),
        Triple("Listening Forest","🎧","Spoken English and accents"),
        Triple("Real World City","🌆","Life, work, culture"),
        Triple("Challenge Arena","⚔","Quizzes and boss battles"),
        Triple("Advanced Academy","🐉","C1–C2 mastery")
    )
    private fun save(){prefs.edit().putInt("xp",xp).putInt("gold",gold).putInt("gems",gems).putInt("lessons",lessons).putInt("correct",correct).putInt("shards",shards).putInt("unlocked",unlocked).putString("hero",name).apply()}
    private fun color(c:Int){paint.color=c}
    private fun rect(c:Canvas,x:Float,y:Float,w:Float,h:Float,col:Int){paint.color=col;c.drawRect(x,y,x+w,y+h,paint)}
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,col:Int=Color.WHITE){paint.color=col;paint.textSize=size; c.drawText(s,x,y,paint)}
    private fun box(c:Canvas,x:Float,y:Float,w:Float,h:Float,title:String,fill:Int=Color.rgb(25,40,70)){
        rect(c,x,y,w,h,Color.rgb(7,13,28));rect(c,x+3,y+3,w-6,h-6,Color.rgb(89,126,180));rect(c,x+6,y+6,w-12,h-12,fill);text(c,title,x+16,y+29,18f)
    }
    override fun onDraw(c:Canvas){
        super.onDraw(c); val w=width.toFloat();val h=height.toFloat()
        rect(c,0f,0f,w,h,Color.rgb(17,31,48))
        if(scene=="world") drawWorld(c,w,h) else if(scene=="lesson") drawLesson(c,w,h) else drawMenu(c,w,h)
        postInvalidateDelayed(35)
    }
    private fun drawWorld(c:Canvas,w:Float,h:Float){
        val tile=40f
        for(y in 0..(h/tile).toInt()+1)for(x in 0..(w/tile).toInt()+1){
            val xx=x*tile;val yy=y*tile
            val grass=if((x+y)%3==0)Color.rgb(55,130,76) else Color.rgb(47,113,69)
            rect(c,xx,yy,tile,tile,grass)
            if((x*13+y*7)%11==0)rect(c,xx+10,yy+9,5f,5f,Color.rgb(130,185,94))
        }
        // stone road
        rect(c,w*.38f,0f,w*.18f,h,Color.rgb(174,145,98))
        for(y in 0..(h/34).toInt()) rect(c,w*.38f,y*34f,w*.18f,2f,Color.rgb(124,99,72))
        // river and bridges
        rect(c,0f,h*.70f,w,h*.13f,Color.rgb(42,135,200))
        for(x in 0..(w/45).toInt())rect(c,x*45f,h*.74f,22f,3f,Color.rgb(87,191,239))
        rect(c,w*.43f,h*.68f,w*.12f,h*.18f,Color.rgb(161,117,71))
        // castle
        rect(c,w*.40f,h*.10f,w*.16f,h*.25f,Color.rgb(191,196,204));rect(c,w*.43f,h*.04f,w*.035f,h*.13f,Color.rgb(91,133,197));rect(c,w*.51f,h*.04f,w*.035f,h*.13f,Color.rgb(91,133,197))
        rect(c,w*.46f,h*.20f,w*.045f,h*.15f,Color.rgb(36,48,71))
        // trees
        for(i in 0..18){val x=((i*173)%w.toInt()).toFloat();val y=((i*97)%(h*.85f).toInt()).toFloat(); if(x<w*.36f||x>w*.60f){rect(c,x,y,22f,22f,Color.rgb(25,77,49));rect(c,x+5,y-7,13f,13f,Color.rgb(69,153,75));rect(c,x+9,y+20,5f,12f,Color.rgb(111,77,49))}}
        // player sprite
        val px=if(playerX==0f)w*.47f else playerX;val py=if(playerY==0f)h*.53f else playerY
        rect(c,px-8,py-12,16f,13f,Color.rgb(236,184,137));rect(c,px-10,py-15,20f,7f,Color.rgb(48,43,73));rect(c,px-9,py+1,18f,15f,Color.rgb(55,102,202));rect(c,px-8,py+15,6f,7f,Color.rgb(54,45,40));rect(c,px+2,py+15,6f,7f,Color.rgb(54,45,40))
        box(c,12f,10f,w*.42f,52f,"ENGLISH QUEST  •  "+name)
        text(c,"LV "+(xp/100+1)+"   XP "+xp+"   GOLD "+gold+"   GEMS "+gems,28f,85f,15f,Color.rgb(255,222,126))
        box(c,w*.68f,10f,w*.30f,74f,"WORDSTONE SHARDS: "+shards+"/9")
        text(c,"Touch a region to begin a lesson",w*.35f,h-20f,15f,Color.WHITE)
        // destination signs
        val coords=listOf(.08f to .22f,.17f to .47f,.75f to .22f,.78f to .52f,.12f to .60f,.67f to .66f,.85f to .78f,.27f to .80f,.53f to .86f)
        for(i in regions.indices){val (rx,ry)=coords[i];val xx=w*rx;val yy=h*ry;rect(c,xx-5,yy-22,145f,38f,Color.rgb(16,30,55));rect(c,xx-3,yy-20,141f,34f,if(i<=unlocked)Color.rgb(69,94,137) else Color.rgb(58,61,70));text(c,(if(i<=unlocked)regions[i].second else "🔒")+" "+regions[i].first,xx,yy,12f)}
        // controls
        box(c,12f,h-126f,122f,112f,"MOVE")
        text(c,"   ▲",49f,h-86f,21f);text(c,"◀  ▼  ▶",28f,h-48f,21f)
        box(c,w-155f,h-82f,143f,66f,"TALK / ENTER")
    }
    private fun drawLesson(c:Canvas,w:Float,h:Float){
        rect(c,0f,0f,w,h,Color.rgb(17,28,51))
        box(c,18f,12f,w-36,62f,"⚔ "+region+"  •  ENGLISH TRIAL")
        val pool=questions.filter{it.region==region || region=="Challenge Arena" || region=="Advanced Academy"}
        val q=pool[(qIndex%max(1,pool.size))]
        box(c,28f,92f,w-56,h-180,"📜 "+q.prompt)
        val start=h*.39f
        for(i in q.options.indices){val yy=start+i*52;rect(c,w*.12f,yy,w*.76f,42f,Color.rgb(47,70,108));text(c,("${'A'+i}. "+q.options[i]),w*.15f,yy+27,17f)}
        if(feedback.isNotEmpty()){text(c,feedback.take(85),w*.10f,h-72f,16f,if(feedback.startsWith("Correct"))Color.rgb(117,255,186) else Color.rgb(255,207,124));text(c,q.explain.take(95),w*.10f,h-48f,13f)}
        text(c,"Tap an answer  •  ESC / back area returns to world",w*.10f,h-15f,12f,Color.LTGRAY)
    }
    private fun drawMenu(c:Canvas,w:Float,h:Float){
        box(c,30f,20f,w-60,h-40,"📖 THE SHATTERED WORDS  •  STORY JOURNAL")
        val ch=storyChapters[storyChapter.coerceIn(0,storyChapters.lastIndex)]
        text(c,ch.first,55f,105f,18f,Color.rgb(255,218,125))
        val words=ch.second.split(" "); var line=""; var yy=145f
        for(word in words){val candidate=if(line.isEmpty())word else "$line $word";if(candidate.length>70){text(c,line,55f,yy,15f);yy+=25f;line=word}else line=candidate}
        if(line.isNotEmpty())text(c,line,55f,yy,15f)
        text(c,"Story chapter ${storyChapter+1} / ${storyChapters.size}    •    Shards: $shards / 9",55f,h-90f,15f,Color.rgb(255,218,125))
        text(c,"Tap upper area: next chapter     •     Tap bottom: return to world",55f,h-55f,13f)
    }
    override fun onTouchEvent(e:android.view.MotionEvent):Boolean{
        val w=width.toFloat();val h=height.toFloat()
        if(e.action==MotionEvent.ACTION_DOWN || e.action==MotionEvent.ACTION_UP){
            val x=e.x;val y=e.y
            if(scene=="world"){
                if(y>h-140&&x<145){if(y<h-85){playerY=(if(playerY==0f)h*.53f else playerY)-25f}else{playerX=(if(playerX==0f)w*.47f else playerX)-25f};invalidate();return true}
                if(y>h-90&&x>w-165){scene="menu";invalidate();return true}
                val coords=listOf(.08f to .22f,.17f to .47f,.75f to .22f,.78f to .52f,.12f to .60f,.67f to .66f,.85f to .78f,.27f to .80f,.53f to .86f)
                for(i in coords.indices){val (rx,ry)=coords[i];if(x in (w*rx-10)..(w*rx+155)&&y in (h*ry-35)..(h*ry+22)){if(i>unlocked){dialog="That region is sealed. Complete lessons to unlock it.";scene="menu"}else{region=regions[i].first;scene="lesson";qIndex=0;feedback=""};invalidate();return true}}
                // Tap center road for movement
                playerX=x.coerceIn(30f,w-30f);playerY=y.coerceIn(100f,h-30f)
            }else if(scene=="lesson"){
                if(feedback.isNotEmpty()){if(y<h*.22f&&x<150f){scene="world"}else{qIndex++;feedback="";if(qIndex%3==0){shards++;gems++;unlocked=min(8,unlocked+1);save()}}}
                else{val start=h*.39f;val index=((y-start)/52f).toInt();val pool=questions.filter{it.region==region||region=="Challenge Arena"||region=="Advanced Academy"};val q=pool[qIndex%max(1,pool.size)]
                    if(index in q.options.indices && y>=start){lessons++;if(index==q.answer){xp+=20;gold+=5;correct++;feedback="Correct! +20 XP, +5 gold."}else{hearts=max(0,hearts-1);feedback="Not quite. "+q.explain};save()}
                    else if(y<90f){scene="world"}
                }
            }else if(scene=="menu"){
                if(y>h-115f){scene="world"}else{storyChapter=(storyChapter+1)%storyChapters.size;prefs.edit().putInt("storyChapter",storyChapter).apply()}
            }else{scene="world"}
            invalidate();return true
        }
        return true
    }
}
