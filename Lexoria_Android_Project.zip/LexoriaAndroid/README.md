# Lexoria: The Shattered Words — Android Studio starter

Native Android/Kotlin project; not a website. Includes a drawn top-down pixel-style world, touch interactions, quiz encounters, XP/gold/gems, local save data, nine region concepts, and an expandable story journal with a prologue, seven chapters, and an epilogue.

## Build an APK
1. Install Android Studio on a computer with JDK 17.
2. Open this project folder in Android Studio.
3. Let Gradle sync and download the Android Gradle Plugin/Kotlin dependencies.
4. Choose **Build > Build APK(s)**.
5. Install the debug APK on your Android phone.

## Content and quality notes
The included sample questions were reviewed for basic standard-English correctness. Grammar and usage can vary by context and dialect, so the final curriculum should explain register and accept valid alternatives rather than imply every language variation is wrong. This starter has only a small demonstration question bank and is not a complete A0–C2 course.

## Not implemented yet
This is an early prototype, not a finished commercial game. Animated sprite sheets, proper collision/pathfinding and joystick controls, full battle turn logic, richer NPC dialogue/quests, pet and equipment systems, shops, audio/listening clips, speech assessment, extensive curriculum, accessibility, cloud accounts, automated tests, and production QA remain to be built. Local progress is stored on-device.

This source project has not been compiled or tested on a physical Android device in this environment; no APK is included.
